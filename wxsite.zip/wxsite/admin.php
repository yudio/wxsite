<?php
header("Location: index.php?g=System&m=Admin&a=index");