<?php 
return array (
  'email' => 'true',
  'email_server' => 'smtp.exmail.qq.com',
  'email_port' => '25',
  'email_user' => 'system@zixue100.net',
  'email_pwd' => 'hongcaixia,594',
  'pwd_email_title' => '密码找回',
  'pwd_email_content' => '尊敬的用户{username}:
      这一封是来自远方的信,目的是测试找回您遗失的密码.

请将以下网址复制到浏览器进行验证 {code} 进行验证! ^_^
',
);