<?php 
return array (
  'alipay_name' => '2606524698@qq.com',
  'alipay_pid' => '2088901172131744',
  'alipay_key' => 'h0mlzslmvv3y6woljm6qyon5l3f2vakg',
);