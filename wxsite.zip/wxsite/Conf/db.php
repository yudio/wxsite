<?php
return array(
	
'DB_TYPE'=>'mysql',
	
'DB_HOST'=>'127.0.0.1',
	
'DB_PORT'=>'3306',
	
'DB_NAME'=>'wxsite_db',
	
'DB_USER'=>'root',
	
'DB_PWD'=>'123a',
	
'DB_PREFIX'=>'tp_',

);