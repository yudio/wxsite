﻿<?php 
return array (
  'site_name' => '奈斯伙伴-微信营销专家',
  'site_title' => '奈斯伙伴-微信营销专家',
  'site_url' => 'http://wx.nicepartner.com',
  'site_my' => '奈斯伙伴',
  'ischeckuser' => 'false',
  'ipc' => '',
  'site_qq' => '6465416',
  'baidu_map_api' => '',
  'site_email' => 'nicep@qq.com',
  'keyword' => '奈斯伙伴',
  'content' => '奈斯伙伴-微信营销专家',
  'counts' => '',
  'copyright' => '',
);