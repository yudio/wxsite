<?php 
return array (
  'site_name' => '微信微信营销专家',
  'site_title' => '微信营销专家',
  'site_url' => 'http://wx6.ksweixin.com',
  'site_my' => 'cccc',
  'ischeckuser' => 'true',
  'ipc' => '',
  'site_qq' => '393173370',
  'baidu_map_api' => '2b79c282b0f365ca9782cceb499e6022',
  'site_email' => 'service@555.com',
  'keyword' => '微信',
  'content' => '微信营销专家',
  'counts' => '',
  'copyright' => '',
);