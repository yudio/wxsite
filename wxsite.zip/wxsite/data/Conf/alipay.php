<?php 
return array (
  'alipay_name' => '13311106357',
  'alipay_pid' => '2088602272561030',
  'alipay_key' => 'u8xcygi7mgvbv9dpwnyuiyp3g4759wfp',
);